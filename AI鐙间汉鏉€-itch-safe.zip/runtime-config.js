window.AI_WEREWOLF_CONFIG = {
  // itch.io only hosts static files. For live model calls, deploy server.js elsewhere
  // and set apiBaseUrl to that origin, for example "https://your-domain.example".
  apiBaseUrl: "",
  enableRemoteAi: true,
};
